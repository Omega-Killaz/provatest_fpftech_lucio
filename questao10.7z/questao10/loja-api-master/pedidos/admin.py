from django.contrib import admin
from .models import Pedidos

admin.site.register(Pedidos)
