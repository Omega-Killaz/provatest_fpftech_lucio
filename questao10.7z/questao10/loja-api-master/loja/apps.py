from django.apps import AppConfig


class LojaConfig(AppConfig):
    name = 'loja'
